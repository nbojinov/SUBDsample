<!DOCTYPE html>
<html>
<head>
	<title> Anton Mitkov</title>
</head>
<body>
	Hello  <br/> &nbsp;&nbsp;&nbsp; Anton Mitkov 12 A, 2 number<br/>
	<br/><br/><br/>

<h3>Tips:</h3></br>
	sub_exam_backup1.sql - backup for the first part of the exam</br>
	sub_exam_backup2.sql - backup for the second part of the exam</br>

	If you refresh the page at the bottom of the file you'll see the changes and the time they are made.</br>
	It is possible when you refreshed the page to have an error with first answer because you change the database</br>
	and it affects on the result.</br></br>

<?php
	mysql_connect("localhost", "root","") or die(mysql_error());

		//mysql_query("CREATE DATABASE exam2") or die(mysql_error());

		mysql_select_db("exam2") or die(mysql_error());


/* 1-----------------------------------------------------*/
	//  	mysql_query("CREATE TABLE Article (
	// 		  article_id INT AUTO_INCREMENT,
	// 		  name VARCHAR(30),
	// 		  	 description VARCHAR(20),
	// 		  	 tag_id INT,
	// 		  PRIMARY KEY(article_id))") Or die(mysql_error());

	// 	mysql_query("CREATE TABLE Category (
	// 		category_id INT AUTO_INCREMENT,
	// 		name VARCHAR(20),
	// 		 description VARCHAR(20),
	// 		PRIMARY KEY(category_id))") Or die(mysql_error());

	// 	mysql_query("CREATE TABLE User (
	// 		  user_id INT AUTO_INCREMENT,
	// 		created_on DATE,
	// 		picture_url VARCHAR(50),
	// 		 password VARCHAR(20),
	// 		  PRIMARY KEY(user_id))") Or die(mysql_error());

	// 	mysql_query("CREATE TABLE Tag (
	// 		  tag_id INT AUTO_INCREMENT,
 //         	  second_priority FLOAT,
 //         	  priority INT,
 //         	  cat_id INT UNIQUE,
	// 		  PRIMARY KEY(tag_id))") Or die(mysql_error());

	// 	mysql_query("CREATE TABLE Cat_User (
	// 		  cat_id INT,
	// 		  user_id INT
	// 		  )") Or die(mysql_error());




 // /*3-----------------------------------------------------------------*/
	// 	mysql_query("INSERT INTO Article( name, description, tag_id) VALUES ('5.04', 'blala', 1)");
	// 	mysql_query("INSERT INTO Article( name, description, tag_id) VALUES ('5.04', 'blala', 2)");
	// 	mysql_query("INSERT INTO Article( name, description, tag_id) VALUES ('5.04', 'blala', 3)");

	// 	mysql_query("INSERT INTO Category( name, description) VALUES ('GOGO','dfghj')");
	// 	mysql_query("INSERT INTO Category( name, description) VALUES ('GOGO','dfghj')");
	// 	mysql_query("INSERT INTO Category( name, description) VALUES ('GOGO','dfghj')");

	// 	mysql_query("INSERT INTO USER( created_on, picture_url, password) VALUES ('2012-12-03', 'dfv', 'GOGO' )");
	// 	mysql_query("INSERT INTO USER( created_on, picture_url, password) VALUES ('2012-12-03','sdvfds', 'PACO')");
	// 	mysql_query("INSERT INTO USER( created_on, picture_url, password) VALUES ('2012-12-03', 'sdfsd', 'NASKO')");

	// 	mysql_query("INSERT INTO tag( second_priority, priority, cat_id) VALUES ('1.5',1,2)");
	// 	mysql_query("INSERT INTO tag( second_priority, priority, cat_id) VALUES ('1.25',3,1)");
	// 	mysql_query("INSERT INTO tag( second_priority, priority, cat_id) VALUES ('1.95'2,,3)");


 // 		mysql_query("INSERT INTO Cat_User( cat_id, user_id) VALUES (1,2)");
	// 	mysql_query("INSERT INTO Cat_User( cat_id, user_id) VALUES (1,1)");
	// 	mysql_query("INSERT INTO Cat_User( cat_id, user_id) VALUES (2,3)");





/*4------------------------------------------------------------------------------------*/

/*Which are the Tag(s) for a given User -> tag cat_user  user*/

		 // $pena =  mysql_query("SELECT * FROM Tag INNER JOIN Cat_User ON Tag.cat_id = Cat_User.cat_id 
		 // 	 INNER JOIN User ON User.user_id = Cat_User.user_id WHERE User.user_id = 1");  

		 // ?> THE ANSWER OF THE FIRST QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($pena)){
		 // 	echo $row["user_id"];		
		 // 	echo $row["cat_id"];
		 // 	//echo $row["tag_id"];
	
			// ?> <br/> <?php
		 // }

 /*5-----------------------------------------------------------------------------------------*/
 		//backup_tables('localhost','root','exam2','sub_exam_backup1');	

/*6-------------------------------------------------------------------------------------------*/
		// mysql_query(" CREATE TABLE Category_part1  (
		// 	category_id1 INT AUTO_INCREMENT,
		// 	name VARCHAR(20),
		// 	PRIMARY KEY(category_id1))") Or die(mysql_error());

		// mysql_query("INSERT INTO Category_part1  (name) SELECT name FROM Category ");
		// mysql_query("ALTER TABLE Category  DROP name");
		// mysql_query("ALTER TABLE Category  RENAME TO Category_part2 ");


 /*7--------------------------------------------------------------------------------------------*/
		// backup_tables('localhost','root','exam2','sub_exam_backup2');

/*8-----------------------------------------------------------------------------------------------*/

/*Which are the Article(s) for a given Category --> art tag cat */

		 // $kon =  mysql_query("SELECT * FROM Article INNER JOIN Tag ON Article.tag_id = Tag.tag_id 
			//  INNER JOIN Category_part1 ON Category_part1.category_id1 = Tag.cat_id INNER JOIN Category_part2 ON
			//  Tag.cat_id = Category_part2.category_id  
			//  WHERE Category_part1.category_id1 = 1");	 


		 // ?> THE ANSWER OF THE SECONT QUESTION IS : <br/><?php
		 // while($row = mysql_fetch_array($kon)){		
		 // 	echo $row["category_id1"];
		 // 	echo $row["category_id"];
		 // 	echo $row["cat_id"];
		 // 	echo $row["tag_id"];

			// ?> <br/> <?php
		 // }

		 


?>
</body>
</html>


<?php

	
/* backup the db OR just a table */
function backup_tables($host,$user,$name,$place,$tables = '*')
{
	
	$link = mysql_connect($host,$user,"");
	mysql_select_db($name,$link);
	
	//get all of the tables
	if($tables == '*')
	{
		$tables = array();
		$result = mysql_query('SHOW TABLES');
		//var_dump($result);
		while($row = mysql_fetch_row($result))
		{
			$tables[] = $row[0];
		}
	}
	else
	{
		$tables = is_array($tables) ? $tables : explode(',',$tables);
	}
	

	//cycle through
	foreach($tables as $table)
	{
		$result = mysql_query('SELECT * FROM '.$table);
		$num_fields = mysql_num_fields($result);
		
		$return = 'DROP TABLE '.$table.';';
		$row2 = mysql_fetch_row(mysql_query('SHOW CREATE TABLE '.$table));
		$return = "\n\n".$row2[1].";\n\n";
		
		for ($i = 0; $i < $num_fields; $i++) 
		{
			while($row = mysql_fetch_row($result))
			{
				$return.= 'INSERT INTO '.$table.' VALUES(';
				for($j=0; $j<$num_fields; $j++) 
				{
					$row[$j] = addslashes($row[$j]);
					$row[$j] = ereg_replace("\n","\\n",$row[$j]);
					if (isset($row[$j])) { $return.= '"'.$row[$j].'"' ; } else { $return.= '""'; }
					if ($j<($num_fields-1)) { $return.= ','; }
				}
				$return.= ");\n";
			}
		}
		$return.="\n\n\n";

	$handle = fopen($place.'.sql','a+');
	fwrite($handle,$return);

	}
	fwrite($handle,"--------------------------------------------------------------------------".date('l jS \of F Y h:i:s A'));
	fclose($handle);
}
?>