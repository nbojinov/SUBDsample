

CREATE TABLE `article` (
  `article_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(30) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  `tag_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`article_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO article VALUES("1","5.04","blala","1");
INSERT INTO article VALUES("2","5.04","blala","2");
INSERT INTO article VALUES("3","5.04","blala","3");





CREATE TABLE `cat_user` (
  `cat_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

INSERT INTO cat_user VALUES("1","2");
INSERT INTO cat_user VALUES("1","1");
INSERT INTO cat_user VALUES("2","3");





CREATE TABLE `category` (
  `category_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `description` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO category VALUES("1","GOGO","dfghj");
INSERT INTO category VALUES("2","GOGO","dfghj");
INSERT INTO category VALUES("3","GOGO","dfghj");





CREATE TABLE `tag` (
  `tag_id` int(11) NOT NULL AUTO_INCREMENT,
  `second_priority` float DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `cat_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`tag_id`),
  UNIQUE KEY `cat_id` (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO tag VALUES("1","1.5","1","2");
INSERT INTO tag VALUES("2","1.25","3","1");





CREATE TABLE `user` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `created_on` date DEFAULT NULL,
  `picture_url` varchar(50) DEFAULT NULL,
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO user VALUES("1","2012-12-03","dfv","GOGO");
INSERT INTO user VALUES("2","2012-12-03","sdvfds","PACO");
INSERT INTO user VALUES("3","2012-12-03","sdfsd","NASKO");



--------------------------------------------------------------------------Saturday 26th of April 2014 08:41:13 PM