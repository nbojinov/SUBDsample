import MySQLdb as mdb

con = mdb.connect('localhost', 'root', '951753', 'Task11')

cur = con.cursor()
cur.execute("create table user_part1(id INT NOT NULL, password VARCHAR(255) , PRIMARY KEY (`id`));");
cur.execute("insert into user_part1 (id, password) select id, password from user;");
cur.execute("alter table user rename user_part2;");
cur.execute("alter table user_part2 drop column password;");

rows = cur.fetchall()
